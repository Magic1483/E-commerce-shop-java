package com.example.Manga_shop.Controllers;

import com.example.Manga_shop.Services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import com.example.Manga_shop.models.Product;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;


import java.awt.print.Pageable;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;


@Controller
public class CatalogController {

    @Autowired
    private ProductService productService;


    @GetMapping("/catalog")
    public String catalogMain(Model model, @RequestParam("page")Optional<Integer> page,
                              @RequestParam("size")Optional<Integer> size) {
        int currentPage = page.orElse(1);
        int pageSize = size.orElse(18);

        Page<Product> productPage = productService.findPaginated(PageRequest.of(currentPage-1,pageSize));

        model.addAttribute("productPage",productPage);

        int totalPages = productPage.getTotalPages();
        if(totalPages > 0){
            List<Integer> pageNumbers = IntStream.rangeClosed(1,totalPages)
                    .boxed()
                    .collect(Collectors.toList());
            model.addAttribute("pageNumbers", pageNumbers);
        }
        return "catalogMain";
    }

    @GetMapping("/catalog/add")
    public String catalogAddMain(Model model) {
        return "add-product";
    }

    @PostMapping("/catalog/add")
    public String catalogPostAddMain(@RequestParam String title, @RequestParam String description,
                                     @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date date, @RequestParam String author,
                                     @RequestParam String genre, @RequestParam String tag,
                                     @RequestParam int quantityChapter, @RequestParam int price,
                                     @RequestParam("poster") MultipartFile file1, @RequestParam("screenshot1") MultipartFile file2,
                                     @RequestParam("screenshot2") MultipartFile file3, @RequestParam("screenshot3") MultipartFile file4)
            throws IOException
    {
        Product product = new Product(title, description, date, author, genre, tag, quantityChapter, price);
        productService.saveProduct(product, file1,file2,file3,file4);

        return "redirect:/catalog";
    }

}
