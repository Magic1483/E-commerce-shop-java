package com.example.Manga_shop.Services;

import com.example.Manga_shop.models.Image;
import com.example.Manga_shop.models.Product;
import com.example.Manga_shop.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

@Service
public class ProductService {

    @Autowired
    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public Iterable<Product> listProduct(){
        Iterable<Product> products = productRepository.findAll();
        return products;
    }

    public Page<Product> findPaginated(Pageable pageable){
        int pageSize = pageable.getPageSize();
        int currentPage = pageable.getPageNumber();
        int startItem = currentPage*pageSize;
        List<Product> list;

        if(productRepository.findAll().size() < startItem){
            list= Collections.emptyList();
        }
        else{
            int toIndex=Math.min(startItem + pageSize,productRepository.findAll().size());
            list = productRepository.findAll().subList(startItem,toIndex);
        }

        Page<Product> productPage = new PageImpl<Product>(list, PageRequest.of(currentPage,pageSize),productRepository.findAll().size());

        return productPage;
    }

    public void saveProduct(Product product, MultipartFile file1, MultipartFile file2,
                            MultipartFile file3, MultipartFile file4) throws IOException {
        Image poster;
        Image screenshot1;
        Image screenshot2;
        Image screenshot3;

        if(file1.getSize()!=0){
            poster = toImageEntity(file1);
            poster.setPreviewImage(true);
            product.addImageToProduct(poster);
        }
        if(file2.getSize()!=0){
            screenshot1 = toImageEntity(file2);
            product.addImageToProduct(screenshot1);
        }

        if(file3.getSize()!=0){
            screenshot2 = toImageEntity(file3);
            product.addImageToProduct(screenshot2);
        }
        if(file4.getSize()!=0){
            screenshot3 = toImageEntity(file4);
            product.addImageToProduct(screenshot3);
        }
        Product productFromDb = productRepository.save(product);
        productFromDb.setPreviewImageId(productFromDb.getImages().get(0).getId());
        productRepository.save(product);
    }

    private Image toImageEntity(MultipartFile file) throws IOException {
        Image image = new Image();
        image.setName(file.getName());
        image.setOriginalFileName(file.getOriginalFilename());
        image.setContentType(file.getContentType());
        image.setSize(file.getSize());
        image.setBytes(file.getBytes());
        return image;
    }
}
