package com.example.Manga_shop.repository;

import com.example.Manga_shop.models.Image;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ImageRepository extends JpaRepository<Image,Long> {
}
