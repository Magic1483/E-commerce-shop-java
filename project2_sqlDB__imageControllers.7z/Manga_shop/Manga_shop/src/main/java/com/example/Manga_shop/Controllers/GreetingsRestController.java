package com.example.Manga_shop.Controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class GreetingsRestController {

    @GetMapping("/hello")
    public  String Test(String s){
        return "Hello, " + s;
    }
}

