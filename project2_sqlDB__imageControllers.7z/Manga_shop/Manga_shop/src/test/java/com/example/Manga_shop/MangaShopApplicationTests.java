package com.example.Manga_shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MangaShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
