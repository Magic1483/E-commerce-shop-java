package com.h2.db.model.repository;

import com.h2.db.model.CheckorderEntity;
import com.h2.db.model.TblProduct;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.parameters.P;

import java.util.List;

public interface TblProductRepository  extends CrudRepository<TblProduct, Long> {

    @Query("select p from TblProduct p where p.name=:name")
    List<TblProduct> findProductByName(@Param("name") String game );

    @Query("select p from TblProduct p ")
    List<TblProduct> getAllCategoryNames();

    @Query("select p from TblProduct p where p.category=:category")
    List<TblProduct> findProductByCategory(@Param("category") String category);

    @Query("select p from TblProduct p where p.name LIKE %:name% ")
    List<TblProduct> findProductsLikeName(@Param("name") String name);
}