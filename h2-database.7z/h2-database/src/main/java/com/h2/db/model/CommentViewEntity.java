package com.h2.db.model;

import org.hibernate.annotations.Immutable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Immutable
@Table(name = "COMMENTVIEW")
public class CommentViewEntity {
    @Id
    @Column(name = "ID")
    private Integer id;

    @Column(name = "LOGIN", columnDefinition = "VARCHAR_IGNORECASE(50)")
    private String login;

    @Column(name = "NAME", length = 250)
    private String game;

    @Column(name = "TEXT", length = 250)
    private String text;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getGame() {
        return game;
    }

    public void setGame(String game) {
        this.game = game;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    protected CommentViewEntity() {
    }
}