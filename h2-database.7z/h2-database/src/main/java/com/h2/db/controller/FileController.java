package com.h2.db.controller;

import org.hibernate.tool.schema.internal.exec.ScriptTargetOutputToFile;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

@Controller
public class FileController {

    @RequestMapping(value="/upload", method= RequestMethod.GET)
    public @ResponseBody
    String provideUploadInfo() {
        return "Вы можете загружать файл с использованием того же URL.";
    }

    @RequestMapping(value="/upload", method=RequestMethod.POST)
    public @ResponseBody String handleFileUpload(@RequestParam("name") String name,
                                                 @RequestParam("file") List<MultipartFile> file){
        if (!file.isEmpty()) {
            try {
                for (int i=0;i< file.size();i++) {
                    /*
                    1й вариант загрузки
                    огранчение 3мб
                    byte[] bytes = file.get(i).getBytes();
                    BufferedOutputStream stream =
                            new BufferedOutputStream(new FileOutputStream(new File(file.get(i).getOriginalFilename() + "-uploaded")));
                    stream.write(bytes);
                    stream.close();
                    */

                    //second upload variant(multiple images
                    //PS add db insert for URl
                    String fileLocation = new File("uploaded").getAbsolutePath() + "\\" + file.get(i).getOriginalFilename();

                    System.out.println("/fileLoc "+fileLocation);
                    FileOutputStream output = new FileOutputStream(fileLocation);
                    output.write(file.get(i).getBytes());
                    output.close();
                }
                return "Вы удачно загрузили " + name + " в " + name + "-uploaded !";
            } catch (Exception e) {
                return "Вам не удалось загрузить " + name + " => " + e.getMessage();
            }
        } else {
            return "Вам не удалось загрузить " + name + " потому что файл пустой.";
        }
    }

}