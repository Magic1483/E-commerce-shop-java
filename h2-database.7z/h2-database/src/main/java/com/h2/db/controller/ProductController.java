package com.h2.db.controller;


import com.h2.db.exception.RecordNotFoundException;
import com.h2.db.model.CheckorderEntity;
import com.h2.db.model.EmployeeEntity;
import com.h2.db.model.TblProduct;
import com.h2.db.service.CheckOrderService;
import com.h2.db.service.EmployeeService;
import com.h2.db.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/product")
public class ProductController {

    @Autowired
    ProductService service;

    @Autowired
    EmployeeService service2;

    @Autowired
    CheckOrderService service3;

    @RequestMapping
    public String getAllProduct(Model model)
    {
        System.out.println("getAllProducts");

        List<TblProduct> list = service.getAllProducts();

        model.addAttribute("products", list);

        return "list-products";
    }


    public  List<TblProduct> GetReccomendations(Authentication authentication) throws RecordNotFoundException {
        //GetReccomendation
        List<CheckorderEntity> em=service3.getCheckOrderByLogin(authentication.getName());

        //Games current user
        List<String> games = new ArrayList<>();
        //Users, have current games
        List<String> targetLogin=new ArrayList<>();

        //get games
        for (int i=0;i<em.size();i++)
        {
            games.add(em.get(i).getName());
        }
        //get Logins
        for(int i=0;i<games.size();i++)
        {
            // targetLogin.add(service.getCheckOrderByGame(games.get(i)));
            List<String> tmp=service3.getCheckOrderLoginByGame(games.get(i));
            targetLogin.addAll(tmp);
        }
        //Distinct login
        targetLogin=targetLogin.stream().distinct().collect(Collectors.toList());
        //Recommend games
        List<String> targetGames=new ArrayList<>();
        //--> List recommend games
        for(int i=0;i<targetLogin.size();i++)
        {
            List<String> tmp=service3.getCheckOrderGamesByLogin(targetLogin.get(i));
            targetGames.addAll(tmp);
        }
        targetGames=targetGames.stream().distinct().collect(Collectors.toList());

        List<TblProduct> products=new ArrayList<>();

        for(int i=0;i<targetGames.size();i++)
        {
            // targetLogin.add(service.getCheckOrderByGame(games.get(i)));
            List<TblProduct> tmp=service.getProductByName(targetGames.get(i));
            products.addAll(tmp);
        }

        return products;
    }

    public static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Set<Object> seen = ConcurrentHashMap.newKeySet();
        return t -> seen.add(keyExtractor.apply(t));
    }

    @RequestMapping(path = {"/GamesList","/GamesList/tg_{targetCategory}/{search_req}"})
    public String getAllProductForUsers(Model model,Authentication authentication,@PathVariable("targetCategory") Optional<String> targetCategory,
                                        @PathVariable("search_req") Optional<String> search_req) throws RecordNotFoundException {

        if(search_req.isPresent())
            System.out.println(search_req.get());
        if(targetCategory.isPresent())
            System.out.println(targetCategory.get());

        if(targetCategory.isPresent()|search_req.isPresent()) {
            if ((targetCategory.isPresent()) & (search_req.get().equals("no")))
                {
                    System.out.println("/tgcat " + targetCategory.get());
                    List<TblProduct> list = service.getProductsByCategory(targetCategory.get());
                    model.addAttribute("products", list);
                }
            if ((search_req.isPresent()) & (targetCategory.get().equals("no")))
                {
                    System.out.println("/search_req " + search_req);
                    List<TblProduct> list = service.getProductsLikeName(search_req.get());
                    model.addAttribute("products", list);
                }
        }
        else
        {
            System.out.println("getAllProducts");

            List<TblProduct> list = service.getAllProducts();
            model.addAttribute("products", list);
        }





        System.out.println(authentication.getAuthorities().toString());


        String role=authentication.getAuthorities().toString();
        System.out.println("role "+role);
        model.addAttribute("role",role);

        model.addAttribute("empl",service2.getEmployeeByLogin(authentication.getName()));

        //(service3.getCheckOrderGamesByLogin(authentication.getName())==null)

        try
        {
            System.out.println("games_is "+service3.getCheckOrderGamesByLogin(authentication.getName()).toString());
            //GetReccomendations(authentication);

            if(GetReccomendations(authentication).size()==1)
            {
                model.addAttribute("isRecommendExist",false);
            }
            else
            {
                model.addAttribute("isRecommendExist",true);
            }

            //System.out.println("/isre "+model.getAttribute("isRecommendExist"));

            System.out.println("/colrec "+GetReccomendations(authentication).size());
            List<TblProduct> products=GetReccomendations(authentication);
            model.addAttribute("RecommendProducts",products);
            System.out.println("/isrc "+model.getAttribute("RecommendProducts").toString());
        }
        catch (RecordNotFoundException e)
        {
            e.toString();
            System.out.println("no found checkordrs for recommendations");
            model.addAttribute("isRecommendExist",false);
        }

        //model.addAttribute("category","Horror");



        List<TblProduct> listCategories=service.getCategoriesNames();
        listCategories=listCategories.stream().filter(distinctByKey(TblProduct::getCategory)).collect(Collectors.toList());



        model.addAttribute("category",listCategories);

        System.out.println("/cat4   "+model.getAttribute("category"));

        //model.addAttribute("RecommendProducts", products);

        return "GamesList";
    }



    @RequestMapping(value = "/username", method = RequestMethod.GET)
    @ResponseBody
    public String currentUserName(Authentication authentication) throws RecordNotFoundException {
        return service2.getEmployeeByLogin(authentication.getName()).toString();
    }


    @RequestMapping(path = {"/edit", "/edit/{id}"})
    public String editEmployeeById(Model model, @PathVariable("id") Optional<Long> id)
            throws RecordNotFoundException
    {

        System.out.println("editProductById" + id);
        if (id.isPresent()) {
            TblProduct entity = service.getProductById(id.get());
            model.addAttribute("product", entity);
            return "edit-product";
        } else {
            model.addAttribute("product", new TblProduct());
            return "add-product";
        }

    }

    @RequestMapping(path = "/em2/delete/{id}")
    public String deleteProductById(Model model, @PathVariable("id") Long id)
            throws RecordNotFoundException
    {

        System.out.println("deleteProductById" + id);

        service.deleteProductById(id);
        return "redirect:/product";
    }

    @RequestMapping(path = "edit/createProduct", method = RequestMethod.POST)
    public String createOrUpdateProduct(TblProduct product)
    {
        System.out.println("createOrUpdateProduct ");

        service.createOrUpdateProduct(product);

        return "redirect:/product";
    }
}
